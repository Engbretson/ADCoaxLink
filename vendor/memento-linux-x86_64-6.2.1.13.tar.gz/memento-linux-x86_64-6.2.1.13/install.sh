#!/bin/sh
#
# EURESYS Memento installation script

cd $(dirname $0)
PACKAGE_NAME=$(basename $(pwd))
EURESYS_DIR=/opt/euresys
INSTALL_DIR=$EURESYS_DIR/$PACKAGE_NAME
INSTALL_DIR_SYMLINK=$EURESYS_DIR/memento

echo "Installing Memento Package..."
echo

if [ "`uname -m | grep "i[3-9]86"`" ]; then
    PLATFORM="x86"
else
    PLATFORM="x86_64"
fi

KERVER=`uname -r | cut -f 1 -d .`
if [ $KERVER -lt 3 ]; then
    if [ $KERVER -lt 2 ]; then
        echo "No support for kernel $KERVER.x.x. Sorry."
        exit 1;
    fi
    KERMAJ=`uname -r | cut -f 2 -d .`
    KERMIN=`uname -r | cut -f 1 -d '-' | cut -f 3 -d .`
    if [ $KERMAJ -lt 6 ]; then
        echo "No support for kernel 2.$KERMAJ.x. Sorry."
        exit 1;
    fi
    if [ $KERMIN -lt 28 ]; then
        echo "At least kernel 2.6.28 required ($KERVER.$KERMAJ.$KERMIN detected). Sorry."
        exit 1
    else
        echo "Compiling for $PLATFORM kernel $KERVER.$KERMAJ.$KERMIN (>= 2.6.28)..."
    fi
else
    echo "Compiling for $PLATFORM kernel 3.x.x..."
fi

if [ `id -u` -ne 0 ]; then
    echo "Please install as root."
    exit 1
fi


# Check if the system configuration will allow loading the drivers
if [ -e /etc/sysconfig/hardware/config ]; then 
    if [ ! "`grep LOAD_UNSUPPORTED_MODULES_AUTOMATICALLY=yes /etc/sysconfig/hardware/config`" ]; then
        echo "The system is not configured to automatically load the drivers."
        echo
        echo "Please replace the line LOAD_UNSUPPORTED_MODULES_AUTOMATICALLY=no in "
        echo "/etc/sysconfig/hardware/config by LOAD_UNSUPPORTED_MODULES_AUTOMATICALLY=yes."
        exit 1
    fi
fi

# Check existence of kernel sources
if [ ! -e /lib/modules/$(uname -r)/build/Makefile ]; then
    echo "/lib/modules/$(uname -r)/build/Makefile does not exist."
    echo "Please install kernel sources."
    exit 2
fi

# Check if required development tools are installed
make --version > /dev/null 2>&1
if [ $? != 0 ]; then
    echo "make is not installed."
    echo "Please install make."
    exit 3
fi

# Copy package
rm -rf $INSTALL_DIR
rm -rf $INSTALL_DIR_SYMLINK
mkdir -p $INSTALL_DIR
cp -r --preserve=timestamps * $INSTALL_DIR
ln -s $INSTALL_DIR $INSTALL_DIR_SYMLINK

cd $INSTALL_DIR
rm -f install.sh

# Config files
cp -f --preserve=timestamps shell/memento.conf /etc/modprobe.d/

# Build kernel mode drivers
echo
echo "Installing drivers..."
cd $INSTALL_DIR/drivers/linux/
cp ../precompiled/$PLATFORM/mc_memento.o .
if ! ./build.sh; then
    echo "Please run uninstall.sh to clean the system."
    exit 4
fi

cd /lib/modules/$KERNEL_PATH/
/sbin/depmod
cd

# Insert drivers
echo "Inserting driver modules..."
echo memento
/sbin/rmmod memento 2> /dev/null
/sbin/modprobe memento 2> /dev/null

# Add link
ln -s $INSTALL_DIR_SYMLINK/bin/$PLATFORM/memento /usr/bin

echo
echo "Installation finished!"

# libtiff5 dependency check
ldd /usr/bin/memento 2>/dev/null | grep -q "not found"
if [ $? = 0 ]; then
    echo
    echo "We have detected missing dependencies on your system."
    echo "Please try:"
    echo "    sudo apt-get install libtiff5        (Ubuntu, Debian)"
    echo " or sudo yum install libtiff5            (Red Hat, Fedora, CentOS)"
    echo " or sudo zypper install libtiff5         (openSUSE)"
fi
exit 0
