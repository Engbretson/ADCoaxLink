#!/bin/sh
#
# EURESYS Memento uninstallation script

cd $(dirname $(readlink -e $0))
PACKAGE_NAME=$(basename $(pwd))
EURESYS_DIR=/opt/euresys
INSTALL_DIR=$EURESYS_DIR/$PACKAGE_NAME
INSTALL_DIR_SYMLINK=$EURESYS_DIR/memento
MODULE_NAME=memento

KERNEL_PATH=`uname -r`
DRIVERS_DIR=/lib/modules/$KERNEL_PATH/kernel/drivers/char/

if [ `id -u` -ne 0 ]; then
    echo "Please uninstall as root."
    exit 0
fi

echo "This script will remove all Memento components."
echo -n "Do you want to continue? [y/n]: "
read response
case $response in
    [yY]*) echo "Uninstalling Memento components...";;
    *)     exit 0;;
esac

# Unload drivers
if [ -n "$(/sbin/lsmod | grep "^$MODULE_NAME\b")" ]; then
    /sbin/rmmod $MODULE_NAME
    if [ $? != 0 ]; then
        echo "Uninstallation failed."
        exit 1
    else
        echo "Removed $MODULE_NAME module."
    fi
fi
rm -f $DRIVERS_DIR/$MODULE_NAME.ko

# Remove all files
rm -f /etc/modprobe.d/$MODULE_NAME.conf
rm -rf $INSTALL_DIR
rm -rf $INSTALL_DIR_SYMLINK
rm -rf /dev/memento
rmdir --ignore-fail-on-non-empty $EURESYS_DIR
rm -f /usr/bin/memento

echo "Uninstallation finished!"
