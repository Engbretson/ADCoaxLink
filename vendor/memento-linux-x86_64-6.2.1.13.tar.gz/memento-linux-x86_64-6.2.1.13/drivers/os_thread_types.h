#if defined(EURESYS_UNITTEST)
#include "UnitTests/os_thread_types.h"
#elif defined(EURESYS_LINUX)
#include "./linux/os_thread_types.h"
#elif defined(EURESYS_WDM)
#include "./windows/os_thread_types.h"
#endif
