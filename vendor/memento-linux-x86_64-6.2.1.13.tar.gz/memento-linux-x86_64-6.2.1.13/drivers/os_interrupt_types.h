#if defined EURESYS_UNITTEST && !defined EURESYS_OSAL_UNITTEST
#include "UnitTests/os_interrupt_types.h"
#elif defined EURESYS_LINUX
#include "linux/os_interrupt_types.h"
#elif defined EURESYS_WDM
#include "windows/os_interrupt_types.h"
#endif
