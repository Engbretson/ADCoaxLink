#ifdef EURESYS_WDM
#include "windows\os_timer_types.h"
#else
#include "linux/os_timer_types.h"
#endif
