#ifndef OS_ENTRY_POINTS_HEADER_FILE
#define OS_ENTRY_POINTS_HEADER_FILE

#include "os_types.h"
#include "os_synchro.h"
#include "os_interrupt.h"

#ifdef __cplusplus
extern "C"
{
#endif

typedef struct t_MemResources
{
    PHYSICAL_ADDR Start;
    UINT32 Size;
} OS_MEM_RESOURCE;

#define OS_MAX_RESOURCES 12

typedef struct t_DeviceInfo
{
    PDEVICE ppcidev;
    UINT32 bus;
    UINT32 slot;
    USHORT DeviceID;
    USHORT VendorID;
    USHORT SubDeviceID;
    USHORT SubVendorID;
    OS_MEM_RESOURCE memResources[OS_MAX_RESOURCES];
    UINT32 memResourcesCount;
    OS_IRQ_RESOURCE irqResource;
    BOOLEAN irqAvailable;
} OS_DEVICE_INFO;


INT32 EDDI_API mc_init_module(void);
INT32 EDDI_API mc_add_device(OS_DEVICE_INFO *dev);
void EDDI_API mc_remove_device(PDEVICE pciDevice);
void EDDI_API mc_cleanup_module(void);

INT32 EDDI_API mc_device_open(INT32 Major, INT32 Minor, void **private_data);
INT32 EDDI_API mc_device_release(INT32 Major, INT32 Minor, void **private_data);
INT32 EDDI_API mc_device_read(INT32 Major, INT32 Minor, char *buffer, UINT32 size,
                            void **private_data);
INT32 EDDI_API mc_device_write(INT32 Major, INT32 Minor, PCCHAR buffer, UINT32 size,
                             void **private_data);
INT32 EDDI_API mc_device_ioctl(INT32 Major, INT32 Minor, INT32 cmd, void *arg,
                             void **private_data);
OS_NOTIFICATION_EVENT *EDDI_API mc_device_poll(void **private_data);

#ifdef __cplusplus
}
#endif

#endif

