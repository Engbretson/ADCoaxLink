#ifndef OS_USER_MEMORY_HEADER_FILE
#define OS_USER_MEMORY_HEADER_FILE

#include "os_types.h"

#ifdef __cplusplus
extern "C"
{
#endif

/** Copies n bytes from a user buffer. Returns zero on success.
 **/
UINT32 EDDI_API OsCopyFromUser(void *to, const void *from, UINT32 n);

/** Copies n bytes to a user buffer. Returns zero on success.
 **/
unsigned int EDDI_API OsCopyToUser(void *to, const void *from, unsigned int n);

/** Checks whether reading [at ... at+n[ is allowed for user process.
 **/
BOOLEAN EDDI_API OsUserCanRead(const void *at, size_t n);

/** Checks whether writing [to ... to+n[ is allowed for user process.
 **/
BOOLEAN EDDI_API OsUserCanWrite(void *to, size_t n);

#ifdef __cplusplus
}
#endif

#endif
