#ifndef OS_REQUEST_FIRMWARE_HEADER_FILE
#define OS_REQUEST_FIRMWARE_HEADER_FILE

#include "os_size_t.h"
#include "os_types.h"

#ifdef __cplusplus
extern "C" 
{
#endif

/** OsFirmware structure contains the pointer
 *  to the buffer holding the \param image of the firmware
 *  and the \param size of this image.
 *  It also contains a pointer to an internal
 *  OS specific data.
 */
typedef struct {
    const unsigned char *image;
    size_t size;
    const void *osSpecificValue;
} OsFirmware;


/** OsRequestFirmware requests a firmware whose name is \param firmwareName
 *  from the Windows kernel or the Linux hotplug/udev subsystem.
 *  Upon success, the retrieved firmware is stored at \param firmwareImage.
 *  \param device must be set to a pointer to the DEVICE for which the firmware
 *  is to be loaded.
 *  OsRequestFirmware returns 0 on success and a negative value on error.
 *  OsRequestFirmware can only be called at PASSIVE level.
 */
int EDDI_API OsRequestFirmware(const char *firmwareName, OsFirmware *firmwareImage,
                               PDEVICE device);

void EDDI_API OsReleaseFirmware(OsFirmware *firmwareImage);

#ifdef __cplusplus
}
#endif

#endif
