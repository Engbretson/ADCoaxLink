#ifndef BASIC_DMA_INTERFACE_HEADER_FILE
#define BASIC_DMA_INTERFACE_HEADER_FILE

#include "os_size_t.h"
#include "os_types.h"
#include "os_dma_types.h"

#ifdef __cplusplus
extern "C" 
{
#endif

UINT32 EDDI_API OsGetPageCount(void *address, UINT32 size);

void EDDI_API OsMapDmaPage(PDMA_OBJECT adapter, void *CurrentVa,
                         UINT32 remainingLength, unsigned int *length,
                         PHYSICAL_ADDR *address, MEMORY_DESCRIPTION *memory, int pageIndex);
void EDDI_API OsUnmapDmaPages(PDMA_OBJECT adapter, OS_DMA_PAGE *pageList,
                            unsigned int pageCount, MEMORY_DESCRIPTION *memory, 
                            void **mapRegistersBase, 
                            unsigned int numberOfMapRegisters);

void EDDI_API OsSyncDma(PDMA_OBJECT adapter, unsigned long long physaddr,
                       size_t size);

/** These 4 functions may only be used under Windows.
 **/
MEMORY_DESCRIPTION *EDDI_API OsAllocateLockedMemory(PHYSICAL_ADDR low, 
                                                  PHYSICAL_ADDR high, 
                                                  size_t size);

void EDDI_API OsFreeLockedMemory(MEMORY_DESCRIPTION *memory);

void *EDDI_API OsMapForUser(MEMORY_DESCRIPTION *memory);
void EDDI_API OsUnmapForUser(MEMORY_DESCRIPTION *memory, void *userAddress);

#ifdef __cplusplus
}
#endif

#endif
