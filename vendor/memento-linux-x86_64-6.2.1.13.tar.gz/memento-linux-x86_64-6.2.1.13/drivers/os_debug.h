#include "os_types.h"

#ifdef EURESYS_WDM
#include "windows/os_debug.h"
#elif (defined EURESYS_LINUX || defined EURESYS_UNITTEST)
#include "linux/os_debug.h"
#endif
