#include "mc_linux.h"
#include "../os_synchro.h"
#include "../os_math.h"

#ifndef EURESYS_UNITTEST
int EDDI_API OsSemaInit(OS_SEMA *lock, int initCount, int maxCount) 
{
    sema_init((struct semaphore *) lock, initCount);

    return OS_OK;
}

int EDDI_API OsSemaWait(OS_SEMA *lock) 
{
    int result;
    result=down_interruptible((struct semaphore*)lock);

    if(result<0) 
        return OS_WAIT_ALERTED;

    return OS_OK;
}

int EDDI_API OsSemaWaitUninterruptible(OS_SEMA *lock) 
{
    down((struct semaphore*)lock);

    return OS_OK;
}

int EDDI_API OsSemaTimedWait(OS_SEMA *lock, int timeout) 
{
    return OsSemaWait(lock);
}

int EDDI_API OsSemaRelease(OS_SEMA *lock)
{
    up((struct semaphore*)lock);

    return OS_OK;
}

int EDDI_API OsSemaDelete(OS_SEMA *lock) 
{
    /* nothing to do*/
    return OS_OK;
}


int EDDI_API OsMutexInit(OS_MUTEX *lock) 
{
    return OsSemaInit((OS_SEMA*)lock,1,1);
}

int EDDI_API OsMutexWait(OS_MUTEX *lock) 
{
    return OsSemaWait((OS_SEMA*)lock);
}

int EDDI_API OsMutexWaitUninterruptible(OS_MUTEX *lock) 
{
    return OsSemaWaitUninterruptible((OS_SEMA*)lock);
}

int EDDI_API OsMutexRelease(OS_MUTEX *lock) 
{
    return OsSemaRelease((OS_SEMA*)lock);
}

int EDDI_API OsMutexDelete(OS_MUTEX *lock) 
{
    return OsSemaDelete((OS_SEMA*)lock);
}


int EDDI_API OsSpinLockInit(OS_SPINLOCK *spinlock) 
{
    spin_lock_init((spinlock_t *)spinlock);

    return OS_OK;
}

int EDDI_API OsSpinLockWait(OS_SPINLOCK *spinlock, OS_SPINLOCAL *context) 
{
    spin_lock_bh((spinlock_t *)spinlock);

    return OS_OK;
}

int EDDI_API OsSpinLockRelease(OS_SPINLOCK *spinlock, OS_SPINLOCAL *context) 
{
    spin_unlock_bh((spinlock_t *)spinlock);

    return OS_OK;
}

int EDDI_API OsSpinLockWaitDpc(OS_SPINLOCK *spinlock, OS_SPINLOCAL *context)
{
    spin_lock((spinlock_t *)spinlock);

    return OS_OK;
}

int EDDI_API OsSpinLockReleaseDpc(OS_SPINLOCK *spinlock, OS_SPINLOCAL *context) 
{
    spin_unlock((spinlock_t *)spinlock);

    return OS_OK;
}

int EDDI_API OsSpinLockWaitIrqSafe(OS_SPINLOCK *spinlock, OS_SPINLOCAL *context)
{
    unsigned long flags;

    spin_lock_irqsave((spinlock_t *)spinlock, flags);
    *context = flags;

    return OS_OK;
}

int EDDI_API OsSpinLockReleaseIrqSafe(OS_SPINLOCK *spinlock, OS_SPINLOCAL *context)
{
    unsigned long flags;

    flags = *context;
    spin_unlock_irqrestore((spinlock_t *)spinlock, flags);

    return OS_OK;
}

int EDDI_API OsSpinLockDelete(OS_SPINLOCK *spinlock)
{
    /*nothing to do*/
    return OS_OK;
}

int EDDI_API OsNotificationEventInit(OS_NOTIFICATION_EVENT *event)
{
    init_waitqueue_head((wait_queue_head_t*) &(event->event));
    event->bNotified=FALSE;
    return OS_OK;
}

int EDDI_API OsNotificationEventWait(OS_NOTIFICATION_EVENT *event)
{
    int result=OS_OK;
    wait_queue_head_t *pQueue;
    wait_queue_t wait;

    pQueue=(wait_queue_head_t*)&(event->event);
    init_waitqueue_entry(&wait,current);

    add_wait_queue(pQueue,&wait);
    while(1) {
        set_current_state(TASK_INTERRUPTIBLE);
        if (event->bNotified == TRUE) {
            result=OS_OK;
            break;
        }
        if(signal_pending(current)) {
            result=OS_WAIT_ALERTED;
            break;
        }
        schedule();
    }
    set_current_state(TASK_RUNNING);
    remove_wait_queue(pQueue,&wait);

    return result;
}

int EDDI_API OsNotificationEventWaitUninterruptible(OS_NOTIFICATION_EVENT *event)
{
    int result = OS_OK;
    wait_queue_head_t *pQueue;
    wait_queue_t wait;

    pQueue = (wait_queue_head_t *)&(event->event);
    init_waitqueue_entry(&wait, current);

    add_wait_queue(pQueue, &wait);
    while(1) {
        set_current_state(TASK_UNINTERRUPTIBLE);
        if (event->bNotified == TRUE) {
            result = OS_OK;
            break;
        }
        schedule();
    }
    set_current_state(TASK_RUNNING);
    remove_wait_queue(pQueue, &wait);

    return result;
}

int EDDI_API OsNotificationEventTimedWait(OS_NOTIFICATION_EVENT *event, int timeout)
{
    return OsNotificationEventWait(event);
}

int EDDI_API OsNotificationEventRelease(OS_NOTIFICATION_EVENT *event)
{
    event->bNotified=TRUE;
    wake_up((wait_queue_head_t*) &(event->event));

    return OS_OK;
}

int EDDI_API OsNotificationEventDelete(OS_NOTIFICATION_EVENT *event)
{
    return OS_OK;
}

int EDDI_API OsNotificationEventClear(OS_NOTIFICATION_EVENT *event)
{
    event->bNotified=FALSE;

    return OS_OK;
}

void EDDI_API OsMemoryBarrier()
{
    smp_mb();
}

int EDDI_API OsSynchronizeIrqExecution(OS_SYNC_ROUTINE syncRoutine,
                                       void *syncRoutineContext,
                                       OS_INTERRUPT itr,
                                       OS_SYNC_ITR_LOCAL local)
{
    disable_irq(itr);
    syncRoutine(syncRoutineContext);
    enable_irq(itr);

    return OS_OK;
}
#endif

int EDDI_API OsSleep(unsigned int ms_delay) 
{
    unsigned long timeout;
    LONGLONG before;

    if (ms_delay == 0) {
        timeout = 0;
    } else {
        timeout = ((ms_delay * HZ + 999) / 1000) + 1;
    }

    /* On some systems, when NOHZ is enabled, the jiffies sometimes jump forward
     * and the timer expires too early. We work around this by checking the
     * required time has elapsed and if not go back to sleep. This was seen on
     * kernels < 2.6.27.
     */
    before = OsGetTimeSinceEpoch_us();
    do {
        set_current_state(TASK_UNINTERRUPTIBLE);
        schedule_timeout(timeout);
    } while(OsGetTimeSinceEpoch_us() - before < ms_delay * 1000);

    return OS_OK;
}

int EDDI_API OsStallProcessor(unsigned int usecs) 
{
    if (usecs > 1500) {
        mdelay(usecs / 1000);
        udelay(usecs % 1000);
    } else {
        udelay(usecs);
    }

    return OS_OK;
}

/**
Return the number of processor ticks.
 **/
LONGLONG EDDI_API OsGetCpuTicks()
{
    return get_cycles();
}

struct osal_timestamp {
    LONGLONG monotonic_ns;
    LONGLONG cycles;
    LONGLONG cycles_per_ms;
};

#ifndef EURESYS_UNITTEST
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 28))
static DEFINE_PER_CPU(struct osal_timestamp, time0);
#define HASGETRAWMONOTONIC
#endif
#else
struct osal_timestamp time0;
#define HASGETRAWMONOTONIC
#endif

#define MS_IN_NS (1000 * 1000LL)
#define SEC_IN_NS (1000LL * MS_IN_NS)

static char *mementoclocksource = "unknown";
module_param(mementoclocksource, charp, S_IRUSR | S_IRGRP | S_IROTH);
MODULE_PARM_DESC(mementoclocksource, "current clock source at load time");

#ifdef HASGETRAWMONOTONIC
LONGLONG EDDI_API OsGetInterpolatedTimestamp_ns()
{
    struct osal_timestamp *ref = &get_cpu_var(time0);  
    /* kernel preemption disabled by get_cpu_var. Interruptions are still allowed. */
    
    LONGLONG nowc, oldc, deltac, stamp, cpms;
    do {
        oldc = ref->cycles;
        stamp = ref->monotonic_ns;
        cpms = ref->cycles_per_ms;
    } while (! __sync_bool_compare_and_swap(&ref->cycles, oldc, oldc));
    /* we had no alteration of per-cpu state between reading of cycles and monotonic stamp */
    nowc = get_cycles();

    deltac = nowc - oldc;
    put_cpu_var(time0);  /* kernel preemption re-enabled */
    
    if (cpms > 0 && deltac < cpms && deltac >= 0) {
        /* accepted precision up to 1ms */
        stamp += OsDivS64ByS64(deltac * MS_IN_NS, cpms);
    } else {
        struct timespec ts;
        LONGLONG now_ns, old_ns;
        getrawmonotonic(&ts);
        now_ns = ((LONGLONG)ts.tv_sec * SEC_IN_NS) + ts.tv_nsec;
        
        ref = &get_cpu_var(time0); /* kernel preemption disabled */

        oldc = ref->cycles;
        nowc = get_cycles();
        old_ns = ref->monotonic_ns;
        
        if (__sync_bool_compare_and_swap(&ref->cycles, oldc, nowc) &&
            __sync_bool_compare_and_swap(&ref->monotonic_ns, old_ns, now_ns)) {
            /* succesfully updated state uninterrupted */
            deltac = nowc - oldc;

            if (old_ns && old_ns < now_ns) {
                LONGLONG old_cpms, now_cpms;
                if (deltac > LLONG_MAX / MS_IN_NS) {
                    now_cpms = OsDivS64ByS64(deltac,  OsDivS64ByS64(now_ns - old_ns, MS_IN_NS));
                } else {
                    now_cpms = OsDivS64ByS64(MS_IN_NS * deltac, now_ns - old_ns);
                }
                do {
                    old_cpms = ref->cycles_per_ms;
                } while(! __sync_bool_compare_and_swap(&ref->cycles_per_ms, old_cpms, now_cpms));
            }
        } 
        put_cpu_var(time0);   /* kernel preemption re-enabled */

        stamp = now_ns;
    }
    return stamp;
}

LONGLONG EDDI_API OsGetInterpolatedTimestamp_us()
{
    return OsDivS64ByS64(OsGetInterpolatedTimestamp_ns(), 1000);
}

#endif

/**
  Returns the number of processor ticks in KHz.

  Call it only in the context of a process.
**/
LONGLONG EDDI_API OsGetCpuTicksFrequency() 
{
    LONGLONG ticks;
    static LONGLONG frequency = 0;
    struct timeval tv_start, tv_end;
    unsigned long time_delta, ih, il, tik;

    if (frequency != 0) {
        return frequency;
    }

    ticks = OsGetCpuTicks();
    do_gettimeofday(&tv_start);

    OsSleep(1020);

    do_gettimeofday(&tv_end);
    ticks = OsGetCpuTicks() - ticks;

    if (ticks == 0) {
        return 1; // error
    }

    time_delta = (tv_end.tv_sec-tv_start.tv_sec) * 1000000 + (tv_end.tv_usec - tv_start.tv_usec);

    tik = (ULONG)ticks;
    ih = ((tik & 0xFFFF0000) >> 10) * 1000 / time_delta;
    il = ((tik & 0xFFFF) << 6) * 1000 / time_delta + (1 << 5);

    frequency = (ih << 10) | (il) >> 6;

    return frequency;
}

/**
  Returns the number of microseconds since Epoch (00:00:00 UTC, January 1, 1970).
**/
LONGLONG EDDI_API OsGetTimeSinceEpoch_us()
{
    LONGLONG time_us;
    struct timeval tv;
    do_gettimeofday(&tv);
    time_us = ((LONGLONG)tv.tv_sec * 1000000) + tv.tv_usec;
    return time_us;
}

/**
  Returns the number of microseconds since Epoch (00:00:00 UTC, January 1, 1970).
**/
LONGLONG EDDI_API OsGetSystemTime_us()
{
    return OsGetTimeSinceEpoch_us();
}

LONGLONG EDDI_API OsGetTimestamp()
{
    return OsGetSystemTime_us();
}

#ifdef HASGETRAWMONOTONIC
static LONGLONG EDDI_API OsGetMonotonic_ns()
{
    struct timespec ts;
    getrawmonotonic(&ts);
    return ((LONGLONG)ts.tv_sec * 1000000000) + ts.tv_nsec;
}
static LONGLONG EDDI_API OsGetMonotonic_us()
{
    struct timespec ts;
    getrawmonotonic(&ts);
    return ((LONGLONG)ts.tv_sec * 1000000) + ts.tv_nsec / 1000;
}

#define DEFINE_SELECT_TIMESTAMP_FN(UNIT)                                                                                            \
static LONGLONG EDDI_API OsSelectTimestampFn_##UNIT()                                                                               \
{                                                                                                                                   \
    if (strncmp(mementoclocksource, "acpi_pm", 7) == 0) {                                                                           \
        OsGetMementoTimestamp_us = OsGetInterpolatedTimestamp_us;                                                                   \
        OsGetMementoTimestamp_ns = OsGetInterpolatedTimestamp_ns;                                                                   \
        printk(KERN_WARNING "Clock source 'acpi_pm' would impede memento performance. Experimental interpolation turned on.\n");    \
    } else {                                                                                                                        \
        OsGetMementoTimestamp_us = OsGetMonotonic_us;                                                                               \
        OsGetMementoTimestamp_ns = OsGetMonotonic_ns;                                                                               \
        printk(KERN_DEBUG "Clock source '%s' is satisfying for memento.\n", mementoclocksource);                                    \
    }                                                                                                                               \
    return OsGetMementoTimestamp_##UNIT();                                                                                          \
}

DEFINE_SELECT_TIMESTAMP_FN(us);
DEFINE_SELECT_TIMESTAMP_FN(ns);

LONGLONG EDDI_API (*OsGetMementoTimestamp_us)() = OsSelectTimestampFn_us;
LONGLONG EDDI_API (*OsGetMementoTimestamp_ns)() = OsSelectTimestampFn_ns;

#else
/**
  The following implementation of OsGetMementoTimestamp is not recommended.
  The aim is to define it to be able to install Memento-dependent modules on
  older kernels.
**/
static LONGLONG EDDI_API OsGetWallTime_ns()
{
    struct timespec ts;
    ts = current_kernel_time();
    return ((LONGLONG)ts.tv_sec * 1000000000) + ts.tv_nsec;
}

static LONGLONG EDDI_API OsGetWallTime_us()
{
    struct timespec ts;
    ts = current_kernel_time();
    return ((LONGLONG)ts.tv_sec * 1000000) + ts.tv_nsec / 1000;
}

LONGLONG EDDI_API (*OsGetMementoTimestamp_us)() = OsGetWallTime_us;
LONGLONG EDDI_API (*OsGetMementoTimestamp_ns)() = OsGetWallTime_ns;
#endif

#ifndef EURESYS_UNITTEST
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2, 6, 32))
void OsGetSystemDateTime(OS_DATE_TIME *datetime)
{
    struct timeval now;
    struct tm tm_val;
    do_gettimeofday(&now);
    time_to_tm(now.tv_sec, 0, &tm_val);
    datetime->Year = 1900 + tm_val.tm_year;
    datetime->Month = tm_val.tm_mon + 1;
    datetime->Day = tm_val.tm_mday;
    datetime->Hour = tm_val.tm_hour;
    datetime->Minute = tm_val.tm_min;
    datetime->Second = tm_val.tm_sec;
    datetime->Microsecond = now.tv_usec;
}
#endif
#endif
