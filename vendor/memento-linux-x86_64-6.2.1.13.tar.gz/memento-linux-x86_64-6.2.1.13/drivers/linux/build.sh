# build kernel mode drivers

DRIVERS_LIST='memento'
KERNEL_PATH=`uname -r`
DEST_DIR=/lib/modules/$KERNEL_PATH/kernel/drivers/char/
platform=""

if [ "`uname -m | grep x86_64`" ];
then
    platform=-DEURESYS_64_BITS
fi
platform="-DEURESYS_OSAL_NO_MODULE_INIT $platform"

for module in $DRIVERS_LIST
do
    echo Building $module
    if ! make MODULE=$module PLATFORM="$platform"
    then
        echo Build of $module FAILED!
        exit -1
    fi
    cp -f $module.ko $DEST_DIR
    echo
done

exit 0
