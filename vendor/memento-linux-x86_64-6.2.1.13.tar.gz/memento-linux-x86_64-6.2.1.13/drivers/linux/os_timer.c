#include "mc_linux.h"
#include "../os_timer.h"

static void timer_entry(unsigned long data)
{
    OS_TIMER *timer = (OS_TIMER *)data;
    OS_TIMER_HANDLER routine = timer->routine;
    routine(timer->context);
}

void EDDI_API OsTimerInit(OS_TIMER *timer, OS_TIMER_HANDLER routine, void *context)
{
    struct timer_list *nativeTimer = (struct timer_list *)timer->linux_timer_data;

    timer->routine = routine;
    timer->context = context;
    atomic_set((atomic_t *)&timer->shutdown_flag, 0);
    init_timer(nativeTimer);
    nativeTimer->data = (UINT_PTR)timer;
    nativeTimer->function = timer_entry;
}

void EDDI_API OsTimerCancel(OS_TIMER *timer)
{
    del_timer((struct timer_list *)timer->linux_timer_data);
}

void EDDI_API OsTimerCancelSync(OS_TIMER *timer)
{
    atomic_set((atomic_t *)&timer->shutdown_flag, 1);
    del_timer_sync((struct timer_list *)timer->linux_timer_data);
    // del_timer_sync guarantees that when it returns, the timer function is not running on any CPU
    // it can sleep if it is called from a nonatomic context but busy waits in other situations
    // see http://www.makelinux.net/ldd3/chp-7-sect-4
    atomic_set((atomic_t *)&timer->shutdown_flag, 0);
}

BOOLEAN EDDI_API OsTimerSetOnce(OS_TIMER *timer, UINT32 dueTimeMs)
{
    struct timer_list *nativeTimer = (struct timer_list *)timer->linux_timer_data;
    ULONG expires = jiffies + (dueTimeMs*HZ)/1000;
    if (atomic_read((atomic_t *)&timer->shutdown_flag)) {
        return FALSE;
    }
    mod_timer(nativeTimer, expires);
    return TRUE;
}
