#ifndef OS_DMA_TYPES_HEADER
#define OS_DMA_TYPES_HEADER

#include "os_types.h"

typedef struct pci_dev *PDMA_OBJECT;

typedef struct _MEMORY_DESCRIPTION {
    void * virtualAddress;
    unsigned int length;
    unsigned int offset;
    unsigned int pageCount;
    struct page **pages;
    struct _MEMORY_DESCRIPTION *next;
} MEMORY_DESCRIPTION;

typedef struct {
    int numberOfElements;
    int totalPageCount;
    struct scatterlist *elements;
} SG_LIST;

typedef struct scatterlist SG_ELEMENT;

#endif
