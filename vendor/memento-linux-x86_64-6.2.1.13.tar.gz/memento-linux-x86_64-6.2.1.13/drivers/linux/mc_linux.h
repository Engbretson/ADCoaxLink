#ifndef OS_LINUX_HEADER_FILE
#define OS_LINUX_HEADER_FILE

#ifdef EURESYS_OSAL_UNITTEST
#define EURESYS_OSAL_NO_MODULE_INIT
#include "UnitTests/linuxFakes.h"
#else
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/version.h>
#include <linux/fs.h>
#include <linux/pci.h>
#include <linux/delay.h>
#include <linux/types.h>
#include <linux/pci.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/spinlock.h>
#include <linux/timex.h>
#include <linux/timer.h>
#include <linux/poll.h>
#include <linux/vmalloc.h>

#include <linux/pagemap.h>
#include <linux/swap.h>

#include <asm/uaccess.h>
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 26))
#include <asm/semaphore.h>
#else
#include <linux/semaphore.h>
#endif
#endif

#endif
