#include "mc_linux.h"
#include "../os_crash.h"
#include "../os_dma.h"
#include "../os_basic_dma.h"
#include "../os_memory.h"
#include "../os_debug.h"

// DMA_BIT_MASK(xx) was introduced in 2.6.24 to replace DMA_xxBIT_MASK.
// DMA_xxBIT_MASK macros were removed in 3.1.
#ifndef DMA_64BIT_MASK
#define DMA_64BIT_MASK DMA_BIT_MASK(64)
#define DMA_32BIT_MASK DMA_BIT_MASK(32)
#endif

#ifndef EURESYS_OSAL_UNITTEST
PDMA_OBJECT EDDI_API OsCreateDmaObject(PDEVICE physicalDeviceObject,
                                        BOOLEAN dma64bit, UINT32 maxLength,
                                        unsigned int *numberOfMapRegisters)
{
    struct pci_dev *pciDevice = (struct pci_dev *)physicalDeviceObject;

    //dma addresses are 32bit by default
    if (dma64bit){
        if (!pci_set_dma_mask(pciDevice, DMA_64BIT_MASK)){
            pci_set_consistent_dma_mask(pciDevice, DMA_32BIT_MASK);
        }
        else if (!pci_set_dma_mask(pciDevice, DMA_32BIT_MASK)){
            OsPrintk("64bit dma not available! 32bit dma instead\n");
        }
        else{
            OsPrintk("No suitable dma available\n");
            return NULL;
        }
    }
    return (PDMA_OBJECT)pciDevice;
}

void EDDI_API OsDeleteDmaObject(PDMA_OBJECT dmaAdapter)
{
}

void *EDDI_API OsAllocateCommonBuffer(PHYSICAL_ADDR *physicalAddress,
                                       UINT32 size, PDMA_OBJECT dmaAdapter)
{
    struct pci_dev *pciDevice = (struct pci_dev *)dmaAdapter;
    dma_addr_t dmaAddress;
    void *virtualAddress;

    virtualAddress = pci_alloc_consistent(pciDevice, size, &dmaAddress);
    physicalAddress->QuadPart = dmaAddress;

    return virtualAddress;
}

void EDDI_API OsFreeCommonBuffer(void *virtualAddress,
                                  PHYSICAL_ADDR physicalAddress,
                                  UINT32 size, PDMA_OBJECT dmaAdapter)
{
    struct pci_dev *pciDevice = (struct pci_dev *)dmaAdapter;
    if (virtualAddress) {
        pci_free_consistent(pciDevice, size, virtualAddress,
            (dma_addr_t)(physicalAddress.QuadPart));
    }
}
#endif


MEMORY_DESCRIPTION * EDDI_API OsCreateMemoryDescription(void *buffer,
                                                      unsigned int length)
{
    MEMORY_DESCRIPTION *memory;
    const unsigned long pageOffsetMask = PAGE_SIZE - 1;
    size_t size;

    size = OsGetPageCount(buffer, length) * sizeof(void *);
    memory = (MEMORY_DESCRIPTION *)kmalloc(sizeof(MEMORY_DESCRIPTION), GFP_KERNEL);
    if (memory == NULL) {
        return NULL;
    }
    memory->virtualAddress = buffer;
    memory->length = length;
    memory->offset = (unsigned long)buffer & pageOffsetMask;
    memory->pageCount = 0;
    memory->pages = (struct page **)kmalloc(size, GFP_KERNEL);
    if (memory->pages == NULL) {
        kfree(memory);
        return NULL;
    }
    memory->next = NULL;
    return memory;
}

void EDDI_API OsFreeMemoryDescription(MEMORY_DESCRIPTION *memory)
{
    kfree(memory->pages);
    kfree(memory);
}

#if (LINUX_VERSION_CODE < KERNEL_VERSION(4, 6, 0))
#define GetUserPages    get_user_pages
#define PutPage(page)   page_cache_release(page)
#else
#define GetUserPages    get_user_pages_remote
#define PutPage(page)   put_page(page)
#endif

BOOLEAN EDDI_API OsGetUserPages(MEMORY_DESCRIPTION *memory)
{
    int pageCount;
    int requestedPageCount = OsGetPageCount(memory->virtualAddress, memory->length);

    down_read(&current->mm->mmap_sem);
    pageCount = GetUserPages(current, current->mm,
                             (unsigned long)memory->virtualAddress,
                             requestedPageCount, 1, 0, memory->pages, NULL);
    up_read(&current->mm->mmap_sem);
    if (pageCount < requestedPageCount) {
        int i;
        for (i = 0; i < pageCount; i++) {
            PutPage(memory->pages[i]);
        }
        return FALSE;
    }
    memory->pageCount = pageCount;
    return TRUE;
}

void EDDI_API OsPutUserPages(MEMORY_DESCRIPTION *memory)
{
    unsigned int i;
    for (i = 0; i < memory->pageCount; i++) {
        SetPageDirty(memory->pages[i]);
        PutPage(memory->pages[i]);
    }
}

void EDDI_API OsChainMemoryDescription(MEMORY_DESCRIPTION **memoryList, unsigned int size)
{
    unsigned int i;

    for (i = 0; i < size - 1; i++) {
        MEMORY_DESCRIPTION *memory = memoryList[i];
        while (memory->next)
            memory = memory->next;
        memory->next = memoryList[i + 1];
    }
}

unsigned int GetTotalPageCount(MEMORY_DESCRIPTION *memory)
{
    unsigned int totalPageCount = 0;

    while (memory != NULL) {
        totalPageCount += memory->pageCount;
        memory = memory->next;
    }
    return totalPageCount;
}

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 24))
static void sg_set_page(struct scatterlist *sg, struct page *page, unsigned int length, unsigned int offset)
{
    sg->page = page;
    sg->offset = offset;
    sg->length = length;
}

static void sg_init_table(struct scatterlist *sg, unsigned int nents)
{
    memset(sg, 0, sizeof(*sg) * nents);
}

static struct scatterlist *sg_next(struct scatterlist *sg)
{
    return ++sg;
}
#endif

static void PopulateSglist(MEMORY_DESCRIPTION *memory, struct scatterlist *sglist)
{
    int i;
    int remainingLength;
    struct scatterlist *sgElement = sglist;

    while (memory != NULL) {
        remainingLength = memory->length;
        if (memory->pageCount > 1) {
            sg_set_page(sgElement, memory->pages[0], PAGE_SIZE - memory->offset, memory->offset);
            remainingLength -= sgElement->length;
            sgElement = sg_next(sgElement);
            for (i = 1; i < memory->pageCount; i++) {
                unsigned int length = PAGE_SIZE < remainingLength ? PAGE_SIZE : remainingLength;
                sg_set_page(sgElement, memory->pages[i], length, 0);
                remainingLength -= length;
                sgElement = sg_next(sgElement);
            }
        } else {
            sg_set_page(sgElement, memory->pages[0], memory->length, memory->offset);
            sgElement = sg_next(sgElement);
        }
        memory = memory->next;
    } 
}

int EDDI_API OsGetScatterGatherList(MEMORY_DESCRIPTION *memory,
                                  PDEVICE device, PDMA_OBJECT adapter,
                                  struct ScatterGatherCallbackContext *context)
{
    int result;
    SG_LIST *scatterGatherList;
    struct scatterlist *sglist;
    unsigned int totalPageCount;

    totalPageCount = GetTotalPageCount(memory);
    scatterGatherList = (SG_LIST *)OsMallocAtomic(sizeof(SG_LIST));
    sglist = (struct scatterlist *)OsMallocAtomic(sizeof(struct scatterlist[totalPageCount]));
    if (scatterGatherList == NULL || sglist == NULL) {
        OsFreeAtomic(sglist);
        OsFreeAtomic(scatterGatherList);
        return GET_SG_INSUFFICIENT_RESOURCES;
    }
    sg_init_table(sglist, totalPageCount);
    scatterGatherList->totalPageCount = totalPageCount;

    PopulateSglist(memory, sglist);
    result = pci_map_sg((struct pci_dev *)adapter, sglist, totalPageCount,
                        PCI_DMA_FROMDEVICE);
    if (result <= 0) {
        OsFreeAtomic(sglist);
        OsFreeAtomic(scatterGatherList);
        return GET_SG_FAILURE;
    }
    scatterGatherList->numberOfElements = result;
    scatterGatherList->elements = sglist;
    context->callback(scatterGatherList, context->context);
    return GET_SG_SUCCESS;
}

void EDDI_API OsPutScatterGatherList(SG_LIST **scatterGatherList,
                                   PDMA_OBJECT adapter)
{
    pci_unmap_sg((struct pci_dev *)adapter, (*scatterGatherList)->elements,
                 (*scatterGatherList)->totalPageCount, PCI_DMA_FROMDEVICE);
    OsFreeAtomic((*scatterGatherList)->elements);
    OsFreeAtomic(*scatterGatherList);
    *scatterGatherList = NULL;
}

unsigned int EDDI_API OsGetSgLength(SG_ELEMENT *sgElement)
{
    if (sgElement == NULL) {
        OsCrash(0xffff);
        return 0;
    }
    return sg_dma_len(sgElement);
}

void EDDI_API OsGetSgPhysicalAddress(SG_ELEMENT *sgElement, PHYSICAL_ADDR *address)
{
    if (sgElement == NULL) {
        OsCrash(0xfffe);
    } else {
        address->QuadPart = sg_dma_address(sgElement);
    }
}

SG_ELEMENT *EDDI_API OsGetFirstSgElement(SG_LIST *sgList)
{
    return sgList->elements;
}

SG_ELEMENT *EDDI_API OsGetNextSgElement(SG_ELEMENT *sgElement)
{
    return sg_next(sgElement);
}
