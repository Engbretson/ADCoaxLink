#ifndef OS_DEBUG_HEADER_FILE
#define OS_DEBUG_HEADER_FILE

#ifdef __cplusplus
extern "C"
{
#endif

int EDDI_API OsPrintk(const char *fmt, ...);

#ifdef __cplusplus
}
#endif

#endif
