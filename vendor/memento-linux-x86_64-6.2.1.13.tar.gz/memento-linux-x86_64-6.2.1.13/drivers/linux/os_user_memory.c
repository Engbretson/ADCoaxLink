#ifdef __KERNEL__
#include <asm/uaccess.h>
#endif
#include "mc_linux.h"
#include "../os_user_memory.h"

BOOLEAN EDDI_API OsUserCanRead(const void *at, size_t n)
{
    return (0 != access_ok(VERIFY_READ, at, n)) ? TRUE : FALSE;
}

BOOLEAN EDDI_API OsUserCanWrite(void *at, size_t n)
{
    return (0 != access_ok(VERIFY_WRITE, at, n)) ? TRUE : FALSE;
}

UINT32 EDDI_API OsCopyFromUser(void *to, const void *from, UINT32 n)
{
    return copy_from_user(to, from, n);
}

unsigned int EDDI_API OsCopyToUser(void *to, const void *from, unsigned int n)
{
    return copy_to_user(to, from, n);
}
