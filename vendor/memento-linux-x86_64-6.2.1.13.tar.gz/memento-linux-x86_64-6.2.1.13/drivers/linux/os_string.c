#include "mc_linux.h"
#include "../os_string.h"

INT32 EDDI_API OsSprintf(char *string, PCCHAR format, ...)
{
    INT32 ret;
    va_list args;

    va_start(args, format);
    ret = vsprintf(string, format, args);
    va_end(args);
    return ret;
}

INT32 EDDI_API OsVsnprintf(char *string, size_t size, PCCHAR format, va_list args)
{
    return vsnprintf(string, size, format, args);
}

size_t EDDI_API OsStrLen(const char *string)
{
    return strlen(string);
}
