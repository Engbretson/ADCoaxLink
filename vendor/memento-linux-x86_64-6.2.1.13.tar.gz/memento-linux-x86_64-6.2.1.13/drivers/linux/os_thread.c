#include <asm/current.h>
#include "mc_linux.h"
#include "../os_thread.h"

#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 20))
static void work_entry(void *work)
#else
static void work_entry(struct work_struct *work)
#endif
{
    WORK_CTX *ctx = container_of((OS_TASK *)work, WORK_CTX, task);
    OS_THREAD_ROUTINE routine = ctx->work;
    routine(ctx->context);
}

BOOLEAN EDDI_API OsCreateSystemThread(WORK_CTX *kernelThread)
{
    struct work_struct *work = (struct work_struct *)&kernelThread->task;
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 20))
    INIT_WORK(work, work_entry, work);
#else
    INIT_WORK(work, work_entry);
#endif
    return schedule_work(work) != 0 ? TRUE : FALSE;
}

void EDDI_API OsTerminateSystemThread(void)
{
}

INT32 EDDI_API OsGetThreadId(void)
{
    if (in_interrupt()) {
        return 0;
    } else {
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 24))
        return ((current->pid << 16) | (current->tgid & 0xffff));
#else
        return (task_pid_nr(current) << 16) | (task_tgid_nr(current) & 0xffff);
#endif
    }
}

void EDDI_API OsFlushScheduledWork(void)
{
    flush_scheduled_work();
}
