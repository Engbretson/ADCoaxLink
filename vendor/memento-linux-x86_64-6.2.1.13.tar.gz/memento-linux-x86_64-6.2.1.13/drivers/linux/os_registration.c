#include "../os_registration.h"
#include "mc_linux.h"
#include "os_thread_types.h"
#include "../os_timer.h"
#include "os_synchro_types.h"

extern struct file_operations fops;

// Register/unregister driver function: 
// the driver must be registered once to obtain a major number
// it must also be unregistered when unloaded!
INT32 EDDI_API mc_register_device(const char *name)
{
    INT32 major;

    major = register_chrdev(0, name, &fops);
    return major;
}

void EDDI_API mc_unregister_device(UINT32 major, const char *name)
{
    unregister_chrdev(major, name);
}

static int EDDI_API check_struct_sizes()
{
    if (sizeof(OS_TASK) < sizeof(struct work_struct))
        return -1;
    if (sizeof(OS_SPINLOCK) < sizeof(spinlock_t))
        return -1;
    if (sizeof(OS_EVENT) < sizeof(wait_queue_t))
        return -1;
    if (sizeof(OS_SEMA) < sizeof(struct semaphore))
        return -1;
    if (sizeof(OS_TIMER) < sizeof(struct timer_list))
        return -1;
    return 0;
}

extern struct pci_driver multicam_driver;
extern char *driver_name;
extern int dev_number;

INT32 EDDI_API mc_register_driver(void) {
    int ret;

    ret = check_struct_sizes();
    if (ret < 0)
        return -ENODEV;
    multicam_driver.name = driver_name;
    ret = pci_register_driver(&multicam_driver);
    if (ret < 0)
        return ret;

    if (dev_number == 0) {
        pci_unregister_driver(&multicam_driver);
        return -ENODEV;
    }
    return 0;
}

INT32 EDDI_API mc_unregister_driver(void) {
    pci_unregister_driver(&multicam_driver);

    return 0;
}
