#include "../os_crash.h"
#include "mc_linux.h"
#include "../os_debug.h"

void EDDI_API OsCrash(unsigned short errorCode)
{
    OsPrintk("Oops: 0x%x\n", errorCode);
    BUG();
}

