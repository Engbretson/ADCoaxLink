#include "mc_linux.h"
#include "../os_basic_dma.h"

#define PAGE_OFFSET_MASK (PAGE_SIZE-1)

UINT32 EDDI_API OsGetPageCount(void *address, UINT32 buffer_size)
{
    ULONG page_offset;

    page_offset = ((ULONG)address) & PAGE_OFFSET_MASK;

    if (page_offset == 0) // The buffer is aligned on a page boundary
        return (buffer_size%PAGE_SIZE)? (buffer_size/PAGE_SIZE)+1 : buffer_size/PAGE_SIZE;
    else
        return ((page_offset+(buffer_size%PAGE_SIZE))>PAGE_SIZE)? (buffer_size/PAGE_SIZE)+2 : (buffer_size/PAGE_SIZE)+1;

}

static int PciDmaMappingError(struct pci_dev *pdev, dma_addr_t dma_addr)
{
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 27))
    return pci_dma_mapping_error(dma_addr);
#else
    return pci_dma_mapping_error(pdev, dma_addr);
#endif
}

inline dma_addr_t map_dma(struct pci_dev* adapter, unsigned long addr,
                          int size, struct page *native_page) 
{
    dma_addr_t dma_handle;
    int offset = addr & PAGE_OFFSET_MASK;

    dma_handle = pci_map_page(adapter, native_page,
                              offset, size, PCI_DMA_FROMDEVICE);
    if (PciDmaMappingError(adapter, dma_handle)) {
        return 0;
    }

    return dma_handle;
}

void EDDI_API OsMapDmaPage(PDMA_OBJECT adapter, void *CurrentVa,
                         UINT32 remainingLength, unsigned int *length,
                         PHYSICAL_ADDR *address, MEMORY_DESCRIPTION *memory, int pageIndex)
{
    dma_addr_t physaddr;
    struct page *native_page;

    if (CurrentVa == NULL) {
        address->LowPart = 0;
        address->HighPart = 0;
        return;
    }

    if (remainingLength<PAGE_SIZE) {
        *length = remainingLength;
    } else {
        if ( ((ULONG)CurrentVa) & PAGE_OFFSET_MASK) {
            *length = PAGE_SIZE - ( ((ULONG)CurrentVa) & PAGE_OFFSET_MASK);
        } else {
            *length = PAGE_SIZE;
        }
    }

    if (pageIndex >= memory->pageCount) {
        address->QuadPart = 0;
        return;
    }
    native_page = memory->pages[pageIndex];
    physaddr = map_dma(adapter, (ULONG)CurrentVa, *length, native_page);
    address->QuadPart = physaddr;
    return;
}

void EDDI_API OsUnmapDmaPages(PDMA_OBJECT adapter, OS_DMA_PAGE *pageList,
                            unsigned int pageCount, MEMORY_DESCRIPTION *memory,
                            void **mapRegistersBase, 
                            unsigned int numberOfMapRegisters)
{
    dma_addr_t dmaHandle;
    size_t size;
    unsigned int i;

    for (i = 0; i < pageCount; i++) {
        dmaHandle = pageList[i].Base.QuadPart;
        size = pageList[i].Length;
        pci_unmap_page(adapter, dmaHandle, size, PCI_DMA_FROMDEVICE);
    }
}

void EDDI_API OsSyncDma(PDMA_OBJECT adapter, unsigned long long physaddr,
                       size_t size)
{
    pci_dma_sync_single_for_cpu(adapter, physaddr, size, PCI_DMA_FROMDEVICE);
}

MEMORY_DESCRIPTION *EDDI_API OsAllocateLockedMemory(PHYSICAL_ADDR low, 
                                                  PHYSICAL_ADDR high, 
                                                  size_t size)
{
    return NULL;
}

void EDDI_API OsFreeLockedMemory(MEMORY_DESCRIPTION *memory) {}

void *EDDI_API OsMapForUser(MEMORY_DESCRIPTION *memory)
{
    return NULL;
}

void EDDI_API OsUnmapForUser(MEMORY_DESCRIPTION *memory, void *userAddress) {}
